"""Flask API dan penyaji frontend. Jalankan: python app.py."""
from pathlib import Path
import hashlib
import json
import logging
import os
import re
import joblib
import numpy as np
from flask import Flask, jsonify, request, send_file
from werkzeug.exceptions import HTTPException, BadRequest
from hoax_model import MODEL_NAME, MIN_CHARACTERS, MAX_CHARACTERS

ROOT = Path(__file__).resolve().parent


class ModelService:
    def __init__(self, directory):
        self.pipeline = None
        self.metadata = None
        try:
            directory = Path(directory)
            path = directory / 'pipeline.joblib'
            metadata = json.loads((directory / 'metadata.json').read_text(encoding='utf-8'))
            if hashlib.sha256(path.read_bytes()).hexdigest() != metadata['pipeline_sha256']:
                raise ValueError('Checksum model tidak sesuai metadata')
            # joblib dapat mengeksekusi kode: hanya muat artefak lokal yang dipercaya.
            pipeline = joblib.load(path)
            if set(pipeline.classes_) != {'hoaks', 'non_hoaks'}:
                raise ValueError('Kelas pipeline tidak sesuai kontrak')
            if not {'tfidf', 'classifier'} <= set(pipeline.named_steps):
                raise ValueError('Pipeline tidak sesuai kontrak')
            self.pipeline, self.metadata = pipeline, metadata
        except FileNotFoundError:
            logging.getLogger(__name__).warning('Model belum tersedia. Jalankan scripts/train.py, kemudian restart server.')
        except Exception:
            logging.getLogger(__name__).exception('Artefak model tidak dapat dimuat; prediksi dinonaktifkan.')

    @property
    def ready(self):
        return self.pipeline is not None

    def predict(self, text):
        # Tolak semua fitur nol; jangan mengembalikan keputusan berbasis intercept saja.
        if self.pipeline.named_steps['tfidf'].transform([text]).nnz == 0:
            raise ValueError('OUT_OF_VOCABULARY')
        probabilities = self.pipeline.predict_proba([text])[0]
        if not np.isfinite(probabilities).all() or not np.isclose(probabilities.sum(), 1):
            raise RuntimeError('Probabilitas model tidak valid')
        index = int(np.argmax(probabilities))
        return {
            'prediction': str(self.pipeline.classes_[index]),
            'confidence': float(probabilities[index]),
            'probabilities': {str(label): float(p) for label, p in zip(self.pipeline.classes_, probabilities)},
        }


def create_app(config=None):
    app = Flask(__name__)
    app.config.update(MAX_CONTENT_LENGTH=128 * 1024, MODEL_DIR=os.environ.get('MODEL_DIR', str(ROOT / 'models')),
                      JSON_SORT_KEYS=False)
    if config:
        app.config.update(config)
    service = ModelService(app.config['MODEL_DIR'])
    app.extensions['model_service'] = service

    def fail(code, message, status):
        return jsonify(ok=False, error={'code': code, 'message': message}, prediction=None,
                       confidence=None, model=MODEL_NAME), status

    @app.get('/')
    def home():
        path = ROOT / 'templates/index.html'
        if not path.exists():
            return fail('FRONTEND_UNAVAILABLE', 'Frontend belum dibangun. Jalankan langkah build pada README.', 503)
        return send_file(path)

    @app.get('/api/status')
    def status():
        return jsonify(ok=True, ready=service.ready, model=MODEL_NAME,
                       min_characters=MIN_CHARACTERS, max_characters=MAX_CHARACTERS)

    @app.get('/api/model-card')
    def model_card():
        if not service.ready:
            return fail('MODEL_UNAVAILABLE', 'Model belum tersedia. Latih model lalu restart server.', 503)
        metadata = service.metadata
        return jsonify(ok=True, model=MODEL_NAME, dataset=metadata['dataset'],
                       evaluation=metadata['evaluation'], limitations=metadata['limitations'])

    @app.post('/api/predict')
    def predict():
        if not request.is_json:
            return fail('UNSUPPORTED_MEDIA_TYPE', 'Gunakan Content-Type application/json.', 415)
        try:
            payload = request.get_json()
        except BadRequest:
            return fail('INVALID_JSON', 'Isi request bukan JSON yang valid.', 400)
        if not isinstance(payload, dict) or not isinstance(payload.get('text'), str):
            return fail('INVALID_TEXT', 'Request harus berupa objek JSON dengan kolom text bertipe string.', 400)
        text = payload['text'].strip()
        if not text:
            return fail('EMPTY_TEXT', 'Masukkan isi berita sebelum melakukan analisis.', 400)
        if len(text) > MAX_CHARACTERS:
            return fail('TEXT_TOO_LONG', f'Teks melebihi batas {MAX_CHARACTERS:,} karakter.'.replace(',', '.'), 400)
        if len(text) < MIN_CHARACTERS:
            return fail('TEXT_TOO_SHORT', f'Masukkan setidaknya {MIN_CHARACTERS} karakter agar teks memiliki cukup konteks.', 400)
        if len(re.findall(r'[^\W\d_]{2,}', text, flags=re.UNICODE)) < 5:
            return fail('INSUFFICIENT_WORDS', 'Masukkan isi berita dengan setidaknya lima kata alfabet, bukan hanya angka atau simbol.', 400)
        if not service.ready:
            return fail('MODEL_UNAVAILABLE', 'Model belum tersedia. Latih model lalu restart server.', 503)
        try:
            result = service.predict(text)
        except ValueError as exc:
            if str(exc) == 'OUT_OF_VOCABULARY':
                return fail('OUT_OF_VOCABULARY', 'Kosakata teks tidak dikenali model. Coba berita berbahasa Indonesia yang lebih lengkap.', 422)
            app.logger.exception('Prediksi gagal tanpa mencatat teks pengguna.')
            return fail('PREDICTION_FAILED', 'Terjadi gangguan pada model. Coba lagi atau hubungi pengelola aplikasi.', 500)
        except Exception:
            app.logger.exception('Prediksi gagal tanpa mencatat teks pengguna.')
            return fail('PREDICTION_FAILED', 'Terjadi gangguan pada model. Coba lagi atau hubungi pengelola aplikasi.', 500)
        return jsonify(ok=True, model=MODEL_NAME, message='Hasil merupakan prediksi model, bukan verifikasi fakta.', **result)

    @app.errorhandler(HTTPException)
    def http_error(error):
        messages = {413: ('PAYLOAD_TOO_LARGE', 'Ukuran request melebihi batas 128 KiB.'),
                    404: ('NOT_FOUND', 'Endpoint tidak ditemukan.'),
                    405: ('METHOD_NOT_ALLOWED', 'Metode HTTP tidak diizinkan untuk endpoint ini.')}
        code, message = messages.get(error.code, ('HTTP_ERROR', 'Request tidak dapat diproses.'))
        return fail(code, message, error.code or 500)

    @app.errorhandler(Exception)
    def unexpected_error(error):
        app.logger.exception('Kesalahan internal aplikasi.')
        return fail('INTERNAL_ERROR', 'Terjadi gangguan pada server. Silakan coba lagi.', 500)

    @app.after_request
    def headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        if request.path.startswith('/api/'):
            response.headers['Cache-Control'] = 'no-store'
        return response

    return app


app = create_app()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=False)
