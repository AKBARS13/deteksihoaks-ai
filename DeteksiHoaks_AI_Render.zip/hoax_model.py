"""Pemrosesan konsisten untuk pelatihan dan inferensi. Tanpa koneksi jaringan."""
import html
import re
import unicodedata

MODEL_NAME = 'tfidf_logistic_regression'
MIN_CHARACTERS = 50
MAX_CHARACTERS = 20_000


def clean_text(text: str) -> str:
    text = unicodedata.normalize('NFKC', html.unescape(text)).lower()
    text = re.sub(r'https?://\S+|www\.\S+', ' ', text)
    text = re.sub(r'<[^>]+>', ' ', text)
    return ' '.join(text.split())
