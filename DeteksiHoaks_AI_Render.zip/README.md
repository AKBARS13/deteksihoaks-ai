# DeteksiHoaks AI — paket deployment Render Free

Paket ini berisi frontend hasil build, backend Flask, dan pipeline terlatih. Tidak perlu Node.js, pelatihan ulang, database, API key, atau dataset mentah untuk menjalankannya. Model tetap TF-IDF + Logistic Regression; hasil bukan verifikasi fakta.

**Status:** konfigurasi disiapkan dan diuji secara lokal menggunakan Gunicorn. Belum diunggah atau dideploy ke akun Render. Hasil build di layanan hosting belum diverifikasi.

## Langkah 1 — unggah ke GitHub

1. Ekstrak ZIP paket ini.
2. Buat repository GitHub, misalnya `deteksihoaks-ai`. Pilih Public atau Private sesuai kebutuhan; untuk repository privat, beri integrasi Render akses hanya ke repo ini.
3. Pilih **Add file → Upload files**. Pada repo yang masih kosong, pilih **uploading an existing file**.
4. Unggah isi folder hasil ekstraksi, bukan berkas ZIP. Pertahankan folder `models`, `templates`, dan `licenses`.
5. Pastikan `app.py` dan `requirements.txt` langsung terlihat di halaman utama repository, bukan tersembunyi satu folder lebih dalam.
6. Klik **Commit changes**.

Berkas minimum:

```text
app.py
hoax_model.py
requirements.txt
.python-version
render.yaml
models/
  pipeline.joblib
  metadata.json
templates/
  index.html
licenses/
```

Tidak perlu mengunggah laporan mahasiswa, identitas, dataset mentah, arsip skill, atau folder node_modules. Jika `.python-version` tidak ikut terunggah, environment variable PYTHON_VERSION di bawah tetap menentukan versinya.

## Langkah 2 — buat Web Service di Render

1. Buka https://dashboard.render.com/ dan buat/login akun.
2. Pilih **New → Web Service**, bukan Static Site.
3. Hubungkan GitHub dan pilih repository tersebut. Periksa izin akses integrasi.
4. Isi pengaturan berikut:

| Pengaturan | Nilai |
|---|---|
| Name | Nama unik pilihanmu, misalnya deteksihoaks-namakamu |
| Language/Runtime | Python 3 |
| Branch | main, atau branch tempat kode disimpan |
| Root Directory | Kosong jika app.py ada di root repo |
| Build Command | `pip install -r requirements.txt` |
| Start Command | `gunicorn app:app --bind 0.0.0.0:$PORT --workers 1 --threads 2 --timeout 120 --access-logfile -` |
| Instance/Compute Plan | **Free** |
| Health Check Path | `/api/status` |

Tambahkan environment variables:

```text
PYTHON_VERSION=3.13.16
OMP_NUM_THREADS=1
OPENBLAS_NUM_THREADS=1
```

Versi Python mengikuti lingkungan model yang diuji. Jika hosting menolak versi tersebut, simpan pesan build dan periksa versi Python 3.13 yang tersedia; jangan mengganti versi library model secara acak. PORT disediakan Render, tidak perlu dibuat sendiri. MODEL_DIR tidak perlu diisi karena menggunakan folder models bawaan.

5. Pastikan ringkasan biaya menunjukkan **Free / $0**. Jangan pilih Starter atau menambah database/disk berbayar.
6. Klik **Deploy Web Service** lalu tunggu log build dan startup.
7. Render memberikan alamat `https://nama-layanan.onrender.com` setelah deployment. Nama di sini hanya pola URL, bukan alamat yang sudah dibuat.

`render.yaml` juga disertakan untuk deployment Blueprint. Jika menggunakan menu Web Service manual, nilai file ini tidak otomatis menggantikan pengaturan dashboard; isi tabel di atas.

## Langkah 3 — periksa hasil online

- Halaman utama terbuka dan menampilkan **Model terhubung**.
- Buka `/api/status`; nilai `ready` harus `true`. HTTP 200 saja tidak membuktikan model siap, karena endpoint juga melaporkan status ketika model gagal dimuat.
- Coba analisis teks berita minimal 50 karakter.
- Periksa dialog metode dan evaluasi: data uji 108, akurasi 75%, macro F1 sekitar 0,728.
- Coba input kosong; aplikasi harus memberi pesan validasi, bukan label prediksi.

Saat baru bangun dari tidur, hosting dapat menampilkan loading sementara. Tunggu lalu muat ulang sebelum menyimpulkan aplikasi rusak. Model disertakan dalam repository, sehingga tersedia lagi setiap deployment; jangan mengandalkan unggahan file ke filesystem sementara.

## Batas paket gratis

Menurut dokumentasi Render yang diperiksa pada 14 Oktober 2026:

- Free Web Service tidur setelah 15 menit tanpa trafik dan membutuhkan sekitar satu menit untuk aktif kembali.
- Tersedia 750 jam instance gratis per workspace per bulan, dibagi oleh layanan gratis di workspace tersebut.
- Bandwidth dan menit build memiliki kuota terpisah.
- Perubahan filesystem runtime hilang saat restart/redeploy; paket ini tidak memerlukan penyimpanan persisten.
- Jika batas bandwidth/build terlampaui tanpa metode pembayaran, layanan/build dibatasi sesuai kebijakan Render. Jika ada metode pembayaran, penggunaan tambahan tertentu dapat ditagihkan; periksa billing dan spend limit.

Tidak ada janji hosting gratis tanpa batas atau uptime 24/7. Paket ini sesuai untuk demonstrasi tugas, bukan jaminan layanan produksi. Jika tujuanmu benar-benar tanpa tagihan, jangan memilih paket berbayar atau menambahkan metode pembayaran untuk overage. Jika dashboard meminta pembayaran atau syaratnya berbeda, berhenti dan periksa kembali sebelum melanjutkan.

Sumber resmi:
- https://render.com/docs/free
- https://render.com/docs/deploy-flask
- https://render.com/articles/platforms-with-a-real-free-tier-for-developers-in-2026

## Kenapa bukan cukup drag-and-drop ke Netlify?

Paket yang sekarang memakai proses Python Flask dan Scikit-learn. Mengunggah HTML saja hanya menayangkan antarmuka; endpoint `/api/predict` tidak ikut berjalan. Agar tetap memakai Netlify untuk frontend, backend Python perlu dihosting terpisah dan request diproksikan. Jalur satu layanan Render lebih sederhana untuk proyek ini dan mempertahankan semua kode model.

## Atribusi dan keamanan

Model berasal dari korpus kurasi INDONESIAN HOAX NEWS DETECTION DATASET versi 1, Rahutomo, F.; Yanuar, I.; Asmara, R. A. (2018), Mendeley Data, DOI https://doi.org/10.17632/p3hfgr5j3m.1. Halaman dataset menyatakan CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ . Pembuat dataset tidak dinyatakan mendukung aplikasi ini. Dataset mentah tidak disertakan dalam paket deployment. Model menggunakan 437 train, dievaluasi pada 108 test, dan tidak dilatih ulang saat server berjalan.

Lisensi pustaka frontend dan font disertakan dalam `licenses/`. Hanya muat joblib dari sumber tepercaya; format ini dapat mengeksekusi kode. Checksum memeriksa konsistensi dengan metadata, bukan menjamin keamanan artefak asing.

Aplikasi tidak menyimpan teks pengguna sebagai riwayat. Teks tetap dikirim ke server hosting, sehingga jangan memasukkan informasi pribadi atau rahasia. Gunicorn menggantikan development server Flask, tetapi belum ada rate limit, audit keamanan penuh, atau uji beban. Jika dipakai secara publik di luar demo tugas, tambahkan perlindungan dan kebijakan privasi yang sesuai.
